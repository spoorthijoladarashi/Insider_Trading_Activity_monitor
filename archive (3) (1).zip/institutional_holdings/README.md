# Institutional Holdings (13F) Dataset

## Dataset Overview
Quarterly 13F filings showing institutional investor positions (Hedge Funds, Banks, etc.). **Analytically Parsed**.

**Data Period**: 2025 Q1

### Use Cases
- Track "smart money" positions, market sentiment, and sector allocation.

### Forms Included
13F-HR, 13F-HR/A, 13F-NT

## Data Quality Metrics

| Metric | Value |
|--------|-------|
| Total Records | 11 |
| Completeness Score | 100.0% |
| Missing CIKs | 0 |
| Missing Filing Dates | 0 |
| Duplicate Filings | 0 |
| Data Freshness | 326 days |

## Column Definitions


### cik
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 11

### company_name
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 11

### form_type
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 1

### filing_date
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 5

### filename
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 11

### filing_url
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 11

### parse_status
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 1

### error
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 11
- **Unique Values**: 0

### security_type_table
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 1

### transaction_type
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 1

### insider_analytics
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### filing_analysis
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 11

### issuer_name
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 10

### security_class
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 7

### cusip
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 10

### market_value
- **Type**: float64
- **Non-Null Count**: 11
- **Null Count**: 0
- **Range**: 4355.00 to 458035497.00
- **Mean**: 118422595.73

### shares_amount
- **Type**: float64
- **Non-Null Count**: 11
- **Null Count**: 0
- **Range**: 533.00 to 15578921.00
- **Mean**: 5934682.18

### shares_type
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 1

### investment_discretion
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 3

### sole_voting_shares
- **Type**: float64
- **Non-Null Count**: 11
- **Null Count**: 0
- **Range**: 0.00 to 262851.00
- **Mean**: 23895.55

### shared_voting_shares
- **Type**: float64
- **Non-Null Count**: 11
- **Null Count**: 0
- **Range**: 0.00 to 0.00
- **Mean**: 0.00

### none_voting_shares
- **Type**: float64
- **Non-Null Count**: 11
- **Null Count**: 0
- **Range**: 0.00 to 159065.00
- **Mean**: 14460.45

### total_voting_shares
- **Type**: float64
- **Non-Null Count**: 11
- **Null Count**: 0
- **Range**: 0.00 to 262851.00
- **Mean**: 38356.00

### conviction_score
- **Type**: float64
- **Non-Null Count**: 11
- **Null Count**: 0
- **Range**: 50.00 to 85.60
- **Mean**: 66.33

### owner_name
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### security_title
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### transaction_date
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### transaction_shares
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### transaction_price
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### transaction_code
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### acquired_disposed_code
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### shares_owned_after
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### ownership_form
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### confidence_score
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### transaction_metadata
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### deemed_execution_date
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 11

### dataset_type
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 1

### dataset_name
- **Type**: object
- **Non-Null Count**: 11
- **Null Count**: 0
- **Unique Values**: 1

### is_partial_parse
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 11
- **Unique Values**: 0

### price_notes
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 11
- **Unique Values**: 0

### price_type
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 11
- **Unique Values**: 0

### fields_found
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 11
- **Unique Values**: 0

### price_status
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 11
- **Unique Values**: 0

### fields_missing
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 11
- **Unique Values**: 0

### holding_index
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 11
- **Unique Values**: 0

### parsing_notes
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 11
- **Unique Values**: 0

### parse_quality
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 11
- **Unique Values**: 0

### extraction_success_rate
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 11
- **Unique Values**: 0


## Methodology

This dataset was generated by querying the SEC EDGAR database for filings matching the specified forms.
All data has been normalized, and **key fields have been extracted via sequential and rate-limited parsing** to ensure consistency and prevent abuse.

### Data Processing Steps
1. Bulk download SEC filing index from SEC.gov
2. Filter by relevant form types
3. **Sequential download (concurrency=1) and custom parsing of individual filings (e.g., Form 4 XML, 13F XML) under strict rate limits.**
4. Normalize column names and data types
5. Validate CIK format (10-digit strings)
6. Parse filing dates to ISO format
7. Remove duplicate filings
8. Generate quality metrics
9. **Apply proprietary analytical scoring (Form 4 only).**

## Data Source
SEC Electronic Data Gathering, or EDGAR, is a massive database containing millions of legally mandated 
documents that public companies, foreign private issuers, insiders, and others are required to file with the 
U.S. Securities and Exchange Commission (SEC).

- **Source**: https://www.sec.gov/cgi-bin/browse-edgar
- **Data Updated**: 2026-01-06 18:10:13 UTC

## Access and Attribution
This dataset is compiled from public SEC filings. Please cite the SEC as the primary source when using this data.

## Support
For questions or issues, refer to SEC.gov documentation or EDGAR User Support.

Generated: 2026-01-06T18:10:13.181712
