# SEC Insider Trading Data Quality Report

Generated: 2026-01-06T18:10:36.661967
Version: 2.0
Quarter: 1
Year: 2025

## 📊 Data Quality Overview

### Signal Statistics
- **Total Signals Generated**: 200
- **Rows Processed**: 1441
- **Signals Created**: 985
- **Errors**: 0
- **Skipped Rows**: 456

### Skip Reasons
- **No Price**: 456


## 🎯 Data Enrichment Statistics

### Ticker Resolution
- **Signals with Tickers**: 200/200 (100.0%)
- **Tickers Enriched via edgartools**: 200 (100.0%)

### Price Data
- **Signals with Prices**: 156/200 (78.0%)
- **Prices Enriched via yfinance**: 75 (37.5%)

### Transaction Values
- **Signals with Transaction Values**: 156/200 (78.0%)

## 📋 Transaction Code Reference

| Code | Description | Count | Percentage |
|------|-------------|-------|------------|
| M | Option Exercise | 86 | 43.0% |
| S | Open Market Sale | 64 | 32.0% |
| A | Award/Grant | 44 | 22.0% |
| G | Gift | 4 | 2.0% |
| P | Open Market Purchase | 2 | 1.0% |


## ⚠️ Known Limitations

### Missing Tickers
- **Issue**: Some companies don't have tickers in our mapping
- **Solution**: Enhanced with edgartools Company(cik).tickers lookup
- **Fallbacks**: Company name regex, manual mappings
- **Impact**: 0 signals lack ticker data

### Missing Prices for Certain Transactions
- **Issue**: M (Option Exercise) and G (Gift) transactions often missing prices
- **Solution**: yfinance historical price lookup at transaction date
- **Impact**: 75 signals had prices enriched

### Transaction Code Confusion
- **Issue**: Raw codes like "M", "P", "S" are not descriptive
- **Solution**: Added `transaction_code_description` field
- **Example**: "M" → "Option Exercise"

## 🔧 Data Quality Fields

Every signal includes a `data_quality` object:

```json
{
  "data_quality": {
    "ticker_enriched": true,
    "price_enriched": true,
    "company_name_enriched": false,
    "has_ticker": true,
    "has_price": true,
    "has_transaction_value": true
  }
}
```

### Field Explanations
- `ticker_enriched`: True if ticker was resolved via edgartools (not from original data)
- `price_enriched`: True if price was filled via yfinance historical lookup
- `company_name_enriched`: True if company name was enhanced via edgartools
- `has_ticker`: True if signal has a valid ticker
- `has_price`: True if signal has a valid price (> 0)
- `has_transaction_value`: True if transaction_value > 0

## 📈 Usage Examples

### Check Data Quality
```python
signal = signals[0]
if signal['data_quality']['ticker_enriched']:
    print(f"Ticker was enriched for {signal['company_name']}")
```

### Filter High-Quality Signals
```python
high_quality = [s for s in signals 
                if s['data_quality']['has_ticker'] 
                and s['data_quality']['has_price']]
```

### Transaction Type Analysis
```python
option_exercises = [s for s in signals 
                   if s['transaction_code_description'] == 'Option Exercise']
```

---
*Report generated automatically by Alpha Pipeline v2.0*
