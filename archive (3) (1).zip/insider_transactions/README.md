# Insider Transactions (Form 4) Dataset

## Dataset Overview
CEO/CFO/Director stock trades. **Enhanced with Confidence Scoring and Role/Contextual Data.**

**Data Period**: 2025 Q1

### Use Cases
- Sentiment signal for insider buying/selling, filtered by conviction.

### Forms Included
4, 4/A

## Data Quality Metrics

| Metric | Value |
|--------|-------|
| Total Records | 985 |
| Completeness Score | 100.0% |
| Missing CIKs | 0 |
| Missing Filing Dates | 0 |
| Duplicate Filings | 136 |
| Data Freshness | 284 days |

## Column Definitions


### cik
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 33

### company_name
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 28

### form_type
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 2

### filing_date
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 76

### filename
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 985

### filing_url
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 985

### parse_status
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 1

### error
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 985
- **Unique Values**: 0

### security_type_table
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 2

### transaction_type
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 2

### insider_analytics
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 5

### filing_analysis
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 72

### issuer_name
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 33

### security_class
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 985

### cusip
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 985

### market_value
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 985

### shares_amount
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 985

### shares_type
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 985

### investment_discretion
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 985

### sole_voting_shares
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 985

### shared_voting_shares
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 985

### none_voting_shares
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 985

### total_voting_shares
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 985

### conviction_score
- **Type**: float64
- **Non-Null Count**: 0
- **Null Count**: 985

### owner_name
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 402

### security_title
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 40

### transaction_date
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 76

### transaction_shares
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 737

### transaction_price
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 217

### transaction_code
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 9

### acquired_disposed_code
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 2

### shares_owned_after
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 887

### ownership_form
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 2

### confidence_score
- **Type**: float64
- **Non-Null Count**: 985
- **Null Count**: 0
- **Range**: 26.51 to 100.00
- **Mean**: 80.14

### transaction_metadata
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 922

### deemed_execution_date
- **Type**: object
- **Non-Null Count**: 128
- **Null Count**: 857
- **Unique Values**: 2

### dataset_type
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 1

### dataset_name
- **Type**: object
- **Non-Null Count**: 985
- **Null Count**: 0
- **Unique Values**: 1

### is_partial_parse
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 985
- **Unique Values**: 0

### transaction_index
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 985
- **Unique Values**: 0

### fields_missing
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 985
- **Unique Values**: 0

### parsing_notes
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 985
- **Unique Values**: 0

### extraction_success_rate
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 985
- **Unique Values**: 0

### price_type
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 985
- **Unique Values**: 0

### price_notes
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 985
- **Unique Values**: 0

### fields_found
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 985
- **Unique Values**: 0

### price_status
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 985
- **Unique Values**: 0

### parse_quality
- **Type**: object
- **Non-Null Count**: 0
- **Null Count**: 985
- **Unique Values**: 0


## Methodology

This dataset was generated by querying the SEC EDGAR database for filings matching the specified forms.
All data has been normalized, and **key fields have been extracted via sequential and rate-limited parsing** to ensure consistency and prevent abuse.

### Data Processing Steps
1. Bulk download SEC filing index from SEC.gov
2. Filter by relevant form types
3. **Sequential download (concurrency=1) and custom parsing of individual filings (e.g., Form 4 XML, 13F XML) under strict rate limits.**
4. Normalize column names and data types
5. Validate CIK format (10-digit strings)
6. Parse filing dates to ISO format
7. Remove duplicate filings
8. Generate quality metrics
9. **Apply proprietary analytical scoring (Form 4 only).**

## Data Source
SEC Electronic Data Gathering, or EDGAR, is a massive database containing millions of legally mandated 
documents that public companies, foreign private issuers, insiders, and others are required to file with the 
U.S. Securities and Exchange Commission (SEC).

- **Source**: https://www.sec.gov/cgi-bin/browse-edgar
- **Data Updated**: 2026-01-06 18:10:13 UTC

## Access and Attribution
This dataset is compiled from public SEC filings. Please cite the SEC as the primary source when using this data.

## Support
For questions or issues, refer to SEC.gov documentation or EDGAR User Support.

Generated: 2026-01-06T18:10:13.775654
